﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public class Player
    {
        #region fields

        private int[] _pPos;
        private int _hp;
        private int _sp;
        private int _stepCount;
        private int _level;
        private int _xp;
        private bool _hasKey;
        private bool _hasBurn;
        private bool _getsTurn = true;
        private List<SpAttack> _abilities = new List<SpAttack>();
        private bool _rage;

        #endregion

        #region properties

        public int[] PPos
        {
            get { return _pPos; }
            set { _pPos = value; }
        }

        public int Hp
        {
            get { return _hp; }
            set { _hp = value; }
        }

        public int Sp
        {
            get { return _sp; }
            set { _sp = value; }
        }

        public int StepCount
        {
            get { return _stepCount; }
            set { _stepCount = value; }
        }

        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }

        public int Xp
        {
            get { return _xp; }
            set { _xp = value; }
        }

        public bool HasKey
        {
            get { return _hasKey; }
            set { _hasKey = value; }
        }

        public bool HasBurn
        {
            get { return _hasBurn; }
            set { _hasBurn= value; }
        }

        public bool GetsTurn
        {
            get { return _getsTurn; }
            set { _getsTurn = value; }
        }

        public List<SpAttack> Abilities
        {
            get { return _abilities; }
            set { _abilities = value; }
        }

        public bool Rage
        {
            get { return _rage; }
            set { _rage = value; }
        }

        #endregion

        #region constructors

        public Player(int[] start)
        {
            _level = 1;
            _pPos = start;
            _hp = 6 + (_level * 2);
            _sp = 3 + _level;
            _xp = 0;
            _stepCount = 0;
            _hasKey = false;
            _abilities.Add(SpAttack.LICK);
        }

        #endregion

        #region methods

        public void CalcXp(int gain)
        {
            Xp += gain;

            if (Xp >= 2 + (Level * 2))
            {
                Level++;
                Hp = 6 + (Level * 2);
                Sp = 3 + Level;
                Xp = 0;
            }
        } 

        public void CalcSteps()
        {
            StepCount++;
            if (StepCount >= 4 + Level)
            {
                if (Sp < 3 + Level)
                {
                    Sp++;
                }
                StepCount = 0;
            }
        }
        #endregion
    }
}
