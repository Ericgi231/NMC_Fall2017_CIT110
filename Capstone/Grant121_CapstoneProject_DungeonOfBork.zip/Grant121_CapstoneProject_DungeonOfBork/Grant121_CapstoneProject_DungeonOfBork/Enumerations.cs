﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public enum MainMenuOption
    {
        START
        , OPTIONS
        , EXIT
        , BGCOLOR
        , FGCOLOR
        , NO_INTRO
        , BACK
    }

    public enum GameAction
    {
        MOVE_NORTH
        , MOVE_EAST
        , MOVE_SOUTH
        , MOVE_WEST
    }

    public enum EncounterAction
    {
        ATTACK
        , DEFEND
        , SPECIAL
        , TALK
        , TOUCH
        , EAT
        , ACCEPT
        , DECLINE
        , OK
    }

    public enum SpAttack
    {
        FROST_BOLT
        , SUPLEX
        , FIRE_BALL
        , GUN
        , DROP_KICK
        , LICK
        , SHIELD
        , RAGE
        , NAP
        , TELEPORT
        , SWARM
    }

    public enum Direction
    {
        NORTH = 0
        , EAST = 1
        , SOUTH = 2
        , WEST = 3
        , NONE = 4
    }
}
