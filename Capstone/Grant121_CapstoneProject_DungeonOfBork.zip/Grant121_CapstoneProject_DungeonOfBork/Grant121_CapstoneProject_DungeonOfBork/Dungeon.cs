﻿using System;
using System.Collections.Generic;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public class Dungeon
    {
        #region fields

        private bool[,] _map;
        private int[] _key = new int[2];
        private int[] _end = new int[2];
        private int[] _start = new int[2];
        private int _depth;
        private int _count;
        private int _height;
        private int _width;
        private int[] cPos = new int[2];
        private int[] tPos = new int[2];
        private Stack<int[]> hPos = new Stack<int[]>();
        private Random rng = new Random();

        #endregion

        #region properties

        public bool[,] Map
        {
            get { return _map; }
            set { _map = value; }
        }

        public int[] Key
        {
            get { return _key; }
            set { _key = value; }
        }

        public int[] End
        {
            get { return _end; }
            set { _end = value; }
        }

        public int[] Start
        {
            get { return _start; }
            set { _start = value; }
        }

        public int Depth
        {
            get { return _depth; }
            set { _depth = value; }
        }

        public int Count
        {
            get { return _count; }
            set { _count = value; }
        }

        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }

        #endregion

        #region constructors

        public Dungeon(int height, int width, int depth)
        {
            _depth = depth;
            _height = height + depth;
            _width = width + depth;
            _map = new bool[_height, _width];

            InitializeMap();
            GenerateMap();
            GenerateExit();
        }

        #endregion

        #region methods

        private void InitializeMap()
        {
            for (int row = 0; row < _height; row++)
            {
                for (int col = 0; col < _width; col++)
                {
                    _map[row, col] = false;
                }
            }
            _start = new int[2] { rng.Next(4, _width - 4), rng.Next(4, _height - 4) };
            _map[_start[0], _start[1]] = true;
            cPos = new int[] { _start[0], _start[1] };
        }

        private void GenerateExit()
        {
            for (int row = 0; row < _height; row++)
            {
                for (int col = 0; col < _width; col++)
                {
                    if (_map[row, col] == true)
                    {
                        _end[0] = row;
                        _end[1] = col;
                    }
                }
            }

            for (int row = _height - 1; row > 0; row--)
            {
                for (int col = _width - 1; col > 0; col--)
                {
                    if (_map[row, col] == true)
                    {
                        _key[0] = row;
                        _key[1] = col;
                    }
                }
            }
        }

        private void GenerateMap()
        {
            List<Direction> directions = new List<Direction>()
            {
                Direction.NORTH
                , Direction.EAST
                , Direction.SOUTH
                , Direction.WEST
            };

            List<Direction> validDirections = new List<Direction>();
            int n = 0;
            do
            {
                validDirections = GetValidDirections(directions);
                if (validDirections.Count != 0)
                {
                    switch (validDirections[rng.Next(validDirections.Count)])
                    {
                        case Direction.NORTH:
                            hPos.Push(cPos);
                            cPos[1] = cPos[1] - 1;
                            break;
                        case Direction.EAST:
                            hPos.Push(cPos);
                            cPos[0] = cPos[0] + 1;
                            break;
                        case Direction.SOUTH:
                            hPos.Push(cPos);
                            cPos[1] = cPos[1] + 1;
                            break;
                        case Direction.WEST:
                            hPos.Push(cPos);
                            cPos[0] = cPos[0] - 1;
                            break;
                    }
                }
                else if (hPos.Count > 0)
                {
                    cPos = hPos.Pop();
                }

                _map[cPos[0], cPos[1]] = true;
                n++;
            } while (hPos.Count > 0);
        }

        private List<Direction> GetValidDirections(List<Direction> directions)
        {
            List<Direction> validDirections = new List<Direction>();

            for (int i = 0; i < directions.Count; i++)
            {
                switch (directions[i])
                {
                    case Direction.NORTH:
                        tPos = new int[] { cPos[0], cPos[1] };
                        tPos[1]--;
                        if (ValidtPos(tPos))
                        {
                            if (ValidNorth(tPos))
                            {
                                validDirections.Add(Direction.NORTH);
                            }
                        }
                        break;
                    case Direction.EAST:
                        tPos = new int[] { cPos[0], cPos[1] };
                        tPos[0]++;
                        if (ValidtPos(tPos))
                        {
                            if (ValidEast(tPos))
                            {
                                validDirections.Add(Direction.EAST);
                            }
                        }
                        break;
                    case Direction.SOUTH:
                        tPos = new int[] { cPos[0], cPos[1] };
                        tPos[1]++;
                        if (ValidtPos(tPos))
                        {
                            if (ValidSouth(tPos))
                            {
                                validDirections.Add(Direction.SOUTH);
                            }
                        }
                        break;
                    case Direction.WEST:
                        tPos = new int[] { cPos[0], cPos[1] };
                        tPos[0]--;
                        if (ValidtPos(tPos))
                        {
                            if (ValidWest(tPos))
                            {
                                validDirections.Add(Direction.WEST);
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("broke");
                        break;
                }
            }
            return validDirections;
        }

        private bool ValidtPos(int[] tPos)
        {
            bool valid;

            if (tPos[0] > 0
                && tPos[1] > 0
                && tPos[0] < _width - 1
                && tPos[1] < _height - 1
                && _map[tPos[0], tPos[1]] == false)
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        private bool ValidNorth(int[] tPos)
        {
            bool valid;

            if (_map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0] - 1, tPos[1]] == false
                ||
                _map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] - 1] == false
                ||
                _map[tPos[0] - 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] - 1] == false
                )
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        private bool ValidEast(int[] tPos)
        {
            bool valid;

            if (_map[tPos[0], tPos[1] + 1] == false
                && _map[tPos[0], tPos[1] - 1] == false
                ||
                _map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] + 1] == false
                ||
                _map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] - 1] == false
                )
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        private bool ValidSouth(int[] tPos)
        {
            bool valid;

            if (_map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0] - 1, tPos[1]] == false
                ||
                _map[tPos[0] + 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] + 1] == false
                ||
                _map[tPos[0] - 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] + 1] == false
                )
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        private bool ValidWest(int[] tPos)
        {
            bool valid;

            if (_map[tPos[0], tPos[1] + 1] == false
                && _map[tPos[0], tPos[1] - 1] == false
                ||
                _map[tPos[0] - 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] + 1] == false
                ||
                _map[tPos[0] - 1, tPos[1]] == false
                && _map[tPos[0], tPos[1] - 1] == false
                )
            {
                valid = true;
            }
            else
            {
                valid = false;
            }

            return valid;
        }

        #endregion
    }
}
