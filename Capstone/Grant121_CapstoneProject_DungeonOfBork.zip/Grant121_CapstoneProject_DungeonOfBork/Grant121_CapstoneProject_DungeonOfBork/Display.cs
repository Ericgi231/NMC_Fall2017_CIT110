﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public class Display
    {
        #region methods

        /// <summary>
        /// display a title screen with menu
        /// </summary>
        /// <returns>MainMenuOption user selected</returns>
        public MainMenuOption MainMenu(MainMenuOption[] options)
        {
            //declare vars
            //
            int selected = 0;
            ConsoleKeyInfo uKey;
            bool breaking = false;

            Console.CursorVisible = false;

            //menu loop
            //
            do
            {
                Console.Clear();

                Console.WriteLine("~ THE DUNGEON OF BORK 2 ~");
                Console.WriteLine("~ BY: ERIC GRANT ~");

                Console.WriteLine("\nARROWS TO NAVIGATE\nENTER TO SELECT\n");

                //print options
                //
                for (int i = 0; i < options.Length; i++)
                {
                    if (selected == i)
                    {
                        Console.Write("(*) ");
                        Console.WriteLine(options[i]);
                    }
                    else
                    {
                        Console.Write("( ) ");
                        Console.WriteLine(options[i]);
                    }
                }

                //get input and determine selected option
                //
                uKey = Console.ReadKey(true);

                if (uKey.Key.ToString() == "DownArrow") //user moves down
                {
                    selected++;
                    if (selected > options.Length - 1)
                    {
                        selected = 0;
                    }
                }
                else if (uKey.Key.ToString() == "UpArrow") //user moves up
                {
                    selected--;
                    if (selected < 0)
                    {
                        selected = Convert.ToInt16(options.Length - 1);
                    }
                }
                else if (uKey.Key.ToString() == "Enter") //user selects option
                {
                    breaking = true;
                }

            } while (!breaking);

            Console.CursorVisible = true;
            return options[selected];
        }

        public void ColorMenu(bool bg, Display display)
        {
            //declare class
            //
            Process process = new Process();

            //declare vars
            //
            int selected = 0;
            ConsoleKeyInfo uKey;
            bool breaking = false;

            ConsoleColor[] options = new ConsoleColor[7]
            {
                ConsoleColor.Black
                , ConsoleColor.White
                , ConsoleColor.DarkRed
                , ConsoleColor.DarkCyan
                , ConsoleColor.DarkMagenta
                , ConsoleColor.DarkYellow
                , ConsoleColor.DarkGreen
            };

            Console.CursorVisible = false;

            //menu loop
            //
            do
            {
                Console.Clear();

                Console.WriteLine("~ THE DUNGEON OF BORK 2 ~");
                Console.WriteLine("~ BY: ERIC GRANT ~");

                Console.WriteLine("\nARROWS TO NAVIGATE\nENTER TO SELECT\n");

                //print options
                //
                for (int i = 0; i < options.Length; i++)
                {
                    if (selected == i)
                    {
                        Console.Write("(*) ");
                        Console.WriteLine(options[i]);
                    }
                    else
                    {
                        Console.Write("( ) ");
                        Console.WriteLine(options[i]);
                    }
                }

                if (selected == 7)
                {
                    Console.Write("(*) ");
                    Console.WriteLine("BACK");
                }
                else
                {
                    Console.Write("( ) ");
                    Console.WriteLine("BACK");
                }


                //get input and determine selected option
                //

                uKey = Console.ReadKey(true);

                if (uKey.Key.ToString() == "DownArrow") //user moves down
                {
                    selected++;
                    if (selected > options.Length)
                    {
                        selected = 0;
                    }
                }
                else if (uKey.Key.ToString() == "UpArrow") //user moves up
                {
                    selected--;
                    if (selected < 0)
                    {
                        selected = Convert.ToInt16(options.Length);
                    }
                }
                else if (uKey.Key.ToString() == "Enter") //user selects option
                {
                    if (selected != 7)
                    {
                        if (bg)
                        {
                            Console.BackgroundColor = options[selected];
                        }
                        else
                        {
                            Console.ForegroundColor = options[selected];
                        }
                    }
                    else
                    {
                        breaking = true;
                    }
                }

            } while (!breaking);

            Console.CursorVisible = true;
            process.MainMenuSelection(display.MainMenu(new MainMenuOption[3] { MainMenuOption.FGCOLOR, MainMenuOption.BGCOLOR, MainMenuOption.BACK }), display);
        }

        public GameAction GameMenu(List<GameAction> options, Dungeon dungeon, Player player)
        {
            //declare vars
            //
            int selected = 0;
            ConsoleKeyInfo uKey;
            bool breaking = false;

            Console.CursorVisible = false;

            //menu loop
            //
            do
            {
                Console.Clear();

                int x = 0;
                int y = 0;
                for (int i = 0; i < dungeon.Map.Length; i++)
                {
                    if (dungeon.Map[x, y] == false)
                    {
                        Console.Write(" ");
                    }
                    else if (player.PPos[0] == x && player.PPos[1] == y)
                    {
                        Console.Write("@");
                    }
                    else if (dungeon.End[0] == x && dungeon.End[1] == y)
                    {
                        Console.Write("O");
                    }
                    else if (dungeon.Key[0] == x && dungeon.Key[1] == y)
                    {
                        Console.Write("K");
                    }
                    else
                    {
                        Console.Write("#");
                    }

                    if (x != dungeon.Width - 1)
                    {
                        x++;
                    }
                    else
                    {
                        x = 0;
                        y++;
                        Console.WriteLine();
                    }
                }

                Console.WriteLine($"HP: {player.Hp} / {6 + (player.Level * 2)} | SP: {player.Sp} / {3 + player.Level}");
                Console.WriteLine($"Level: {player.Level} / 10 | XP: {player.Xp} / {2 + (player.Level * 2)}");
                Console.WriteLine($"Steps: {player.StepCount} / {4 + player.Level} | Key: {player.HasKey} | Depth: {dungeon.Depth}");
                Console.WriteLine();

                //print options
                //
                for (int i = 0; i < options.Count; i++)
                {
                    if (selected == i)
                    {
                        Console.Write("(*) ");
                        Console.WriteLine(options[i]);
                    }
                    else
                    {
                        Console.Write("( ) ");
                        Console.WriteLine(options[i]);
                    }
                }

                //get input and determine selected option
                //

                uKey = Console.ReadKey(true);

                if (uKey.Key.ToString() == "DownArrow") //user moves down
                {
                    selected++;
                    if (selected > options.Count - 1)
                    {
                        selected = 0;
                    }
                }
                else if (uKey.Key.ToString() == "UpArrow") //user moves up
                {
                    selected--;
                    if (selected < 0)
                    {
                        selected = Convert.ToInt16(options.Count - 1);
                    }
                }
                else if (uKey.Key.ToString() == "Enter") //user selects option
                {
                    breaking = true;
                }

            } while (!breaking);

            Console.CursorVisible = true;
            return options[selected];
        }

        public EncounterAction EncounterMenu(List<EncounterAction> options, Player player, string text)
        {
            //declare vars
            //
            int selected = 0;
            ConsoleKeyInfo uKey;
            bool breaking = false;

            Console.CursorVisible = false;

            //menu loop
            //
            do
            {
                Console.Clear();
                Console.WriteLine(text);
                Console.WriteLine("\nCorgallia:");
                Console.WriteLine($"HP: {player.Hp} / {6 + (player.Level * 2)} | SP: {player.Sp} / {3 + player.Level}");
                Console.WriteLine($"Level: {player.Level} / 10 | XP: {player.Xp} / {2 + (player.Level * 2)}");
                Console.WriteLine();

                //print options
                //
                for (int i = 0; i < options.Count; i++)
                {
                    if (selected == i)
                    {
                        Console.Write("(*) ");
                        Console.WriteLine(options[i]);
                    }
                    else
                    {
                        Console.Write("( ) ");
                        Console.WriteLine(options[i]);
                    }
                }

                //get input and determine selected option
                //

                uKey = Console.ReadKey(true);

                if (uKey.Key.ToString() == "DownArrow") //user moves down
                {
                    selected++;
                    if (selected > options.Count - 1)
                    {
                        selected = 0;
                    }
                }
                else if (uKey.Key.ToString() == "UpArrow") //user moves up
                {
                    selected--;
                    if (selected < 0)
                    {
                        selected = Convert.ToInt16(options.Count - 1);
                    }
                }
                else if (uKey.Key.ToString() == "Enter") //user selects option
                {
                    breaking = true;
                }

            } while (!breaking);

            Console.CursorVisible = true;
            return options[selected];
        }

        public SpAttack SpAttackMenu(List<SpAttack> options, Player player, string text)
        {
            //declare vars
            //
            int selected = 0;
            ConsoleKeyInfo uKey;
            bool breaking = false;

            Console.CursorVisible = false;

            //menu loop
            //
            do
            {
                Console.Clear();
                Console.WriteLine(text);
                Console.WriteLine("\nCorgallia:");
                Console.WriteLine($"HP: {player.Hp} / {6 + (player.Level * 2)} | SP: {player.Sp} / {3 + player.Level}");
                Console.WriteLine($"Level: {player.Level} / 10 | XP: {player.Xp} / {2 + (player.Level * 2)}");
                Console.WriteLine();

                //print options
                //
                for (int i = 0; i < options.Count; i++)
                {
                    if (selected == i)
                    {
                        Console.Write("(*) ");
                        Console.WriteLine(options[i]);
                    }
                    else
                    {
                        Console.Write("( ) ");
                        Console.WriteLine(options[i]);
                    }
                }

                //get input and determine selected option
                //

                uKey = Console.ReadKey(true);

                if (uKey.Key.ToString() == "DownArrow") //user moves down
                {
                    selected++;
                    if (selected > options.Count - 1)
                    {
                        selected = 0;
                    }
                }
                else if (uKey.Key.ToString() == "UpArrow") //user moves up
                {
                    selected--;
                    if (selected < 0)
                    {
                        selected = Convert.ToInt16(options.Count - 1);
                    }
                }
                else if (uKey.Key.ToString() == "Enter") //user selects option
                {
                    breaking = true;
                }

            } while (!breaking);

            Console.CursorVisible = true;
            return options[selected];
        }

        public void GameOver(Player corgallia, Dungeon dungeon, Process process)
        {
            Console.Clear();
            process.TypeText("YOU DIED", 150);
            Console.WriteLine();
            Console.WriteLine();
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine($"Level: {corgallia.Level}");
            Console.WriteLine($"Depth: {dungeon.Depth}");
            Console.WriteLine($"Abilities: ");
            foreach (SpAttack ability in corgallia.Abilities)
            {
                Console.Write($"{ability}, ");
            }
            Console.WriteLine();
            Console.WriteLine("\nBetter luck next time in...");
            Console.WriteLine("THE DUNGEON OF BORK");
            Console.ReadKey();
            Environment.Exit(0);
        }

        public void GameOver(Player corgallia, Dungeon dungeon, Process process, string text)
        {
            Console.Clear();
            Console.WriteLine(text);
            Console.WriteLine();
            process.TypeText("YOU DIED", 150);
            Console.WriteLine();
            Console.WriteLine();
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine($"Level: {corgallia.Level}");
            Console.WriteLine($"Depth: {dungeon.Depth}");
            Console.WriteLine($"Abilities: ");
            foreach (SpAttack ability in corgallia.Abilities)
            {
                Console.Write($"{ability}, ");
            }
            Console.WriteLine();
            Console.WriteLine("\nBetter luck next time in...");
            Console.WriteLine("THE DUNGEON OF BORK");
            Console.ReadKey();
            Environment.Exit(0);
        }
        #endregion
    }
}
