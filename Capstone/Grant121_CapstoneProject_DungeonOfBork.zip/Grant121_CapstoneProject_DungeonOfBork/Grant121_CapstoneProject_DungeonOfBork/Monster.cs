﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public class Monster
    {
        #region fields

        private string _name;
        private string _type;
        private int _hp;
        private int _sp;
        private SpAttack _power;
        private int _level;
        private bool _getsTurn = true;
        private bool _hasBurn;
        private bool _rage;

        #endregion

        #region properties

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        public int Hp
        {
            get { return _hp; }
            set { _hp = value; }
        }

        public int Sp
        {
            get { return _sp; }
            set { _sp = value; }
        }

        public SpAttack Power
        {
            get { return _power; }
            set { _power = value; }
        }

        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }

        public bool GetsTurn
        {
            get { return _getsTurn; }
            set { _getsTurn = value; }
        }

        public bool HasBurn
        {
            get { return _hasBurn; }
            set { _hasBurn = value; }
        }

        public bool Rage
        {
            get { return _rage; }
            set { _rage = value; }
        }

        #endregion

        #region constructors

        public Monster(Dungeon dungeon, Random rng)
        {
            _level = dungeon.Depth;
            _hp = rng.Next(3+_level) + _level;
            _sp = rng.Next(1,2);
            if (_level > 4)
            {
                _sp++;
                _hp += 2;
            }
            _name = GetName(rng);
            _power = GetPower(rng, out _type);
        }

        #endregion

        #region methods

        public string GetName(Random rng)
        {
            string name = "temp";

            switch (rng.Next(20))
            {
                case 0:
                    name = "Bigby";
                    break;
                case 1:
                    name = "John";
                    break;
                case 2:
                    name = "Mack";
                    break;
                case 3:
                    name = "Loyd";
                    break;
                case 4:
                    name = "Heather";
                    break;
                case 5:
                    name = "Crampton";
                    break;
                case 6:
                    name = "Depresso";
                    break;
                case 7:
                    name = "Tangelo";
                    break;
                case 8:
                    name = "Georgio";
                    break;
                case 9:
                    name = "Phone Bout Dieee";
                    break;
                case 10:
                    name = "Waka";
                    break;
                case 11:
                    name = "Leon";
                    break;
                case 12:
                    name = "Nine";
                    break;
                case 13:
                    name = "Shalashaska";
                    break;
                case 14:
                    name = "Zero";
                    break;
                case 15:
                    name = "Eva";
                    break;
                case 16:
                    name = "Eve";
                    break;
                case 17:
                    name = "Adam";
                    break;
                case 18:
                    name = "Keith";
                    break;
                case 19:
                    name = "Nib";
                    break;
            }

            return name;
        }

        public SpAttack GetPower(Random rng, out string _type)
        {
            SpAttack power = SpAttack.FIRE_BALL;
            _type = "temp";

            switch (rng.Next(11))
            {
                case 0:
                    power = SpAttack.DROP_KICK;
                    _type = "Macho Mouse";
                    break;
                case 1:
                    power = SpAttack.FIRE_BALL;
                    _type = "Blaze Eagle";
                    break;
                case 2:
                    power = SpAttack.FROST_BOLT;
                    _type = "Pengu Mage";
                    break;
                case 3:
                    power = SpAttack.GUN;
                    _type = "Gun Pug";
                    break;
                case 4:
                    power = SpAttack.LICK;
                    _type = "Ant Eater";
                    break;
                case 5:
                    power = SpAttack.NAP;
                    _type = "Phat Cat";
                    break;
                case 6:
                    power = SpAttack.RAGE;
                    _type = "Power Pupper";
                    break;
                case 7:
                    power = SpAttack.SHIELD;
                    _type = "Rock";
                    break;
                case 8:
                    power = SpAttack.SUPLEX;
                    _type = "Whale";
                    break;
                case 9:
                    power = SpAttack.TELEPORT;
                    _type = "Axolotl";
                    break;
                case 10:
                    power = SpAttack.SWARM;
                    _type = "Double Decker Crow";
                    break;
            }

            return power;
        }

        #endregion
    }
}
