﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    class Program
    {
        static void Main(string[] args)
        {
            //instantiate classes
            //
            Display display = new Display();
            Process process = new Process();

            //main methods
            //

            process.MainMenuSelection(display.MainMenu(new MainMenuOption[3] { MainMenuOption.START, MainMenuOption.OPTIONS, MainMenuOption.EXIT }), display);
        }
    }
}
