﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    class Game
    {
        public void MainGameApp()
        {
            int WIDTH = 8;
            int HEIGHT = 8;
            int ENCOUNTERRATE = 5;
            int turnsWithoutEncounter = 0;
            bool encounter = false;
            int dungeonDepth= 1;
            Dungeon dungeon = new Dungeon(WIDTH, HEIGHT, dungeonDepth);
            Player corgallia = new Player(dungeon.Start);
            Display display = new Display();
            Process process = new Process();
            Random rng = new Random();
            List<GameAction> actions = new List<GameAction>();

            //PlayIntro(process);

            while (corgallia.Hp > 0)
            {
                //check for key locations
                //
                if (corgallia.PPos[0] == dungeon.End[0] && corgallia.PPos[1] == dungeon.End[1])
                {
                    if (corgallia.HasKey == true)
                    {
                        corgallia.HasKey = false;
                        dungeonDepth++;
                        dungeon = new Dungeon(WIDTH, HEIGHT, dungeonDepth);

                        corgallia.Hp = corgallia.Hp + rng.Next(4, 10 + corgallia.Level);
                        if (corgallia.Hp > 6 + (corgallia.Level * 2))
                        {
                            corgallia.Hp = 6 + (corgallia.Level * 2);
                        }

                        corgallia.PPos = dungeon.Start;
                    }
                }

                if (corgallia.PPos[0] == dungeon.Key[0] && corgallia.PPos[1] == dungeon.Key[1])
                {
                    corgallia.HasKey = true;
                }

                //lock in encounter if true
                //
                if (encounter)
                {
                    switch (rng.Next(10))
                    {
                        case 0://50% combat
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                            corgallia = EncounterCombat(corgallia, dungeon, process, display, rng);
                            break;
                        case 5://20% passive encounter
                        case 6:
                            corgallia = EncounterPassive(corgallia, process, display, rng);
                            break;
                        case 7://10% find Sp
                            corgallia = EncounterSp(corgallia, process, display, rng);
                            break;
                        case 8://10% find Hp
                            corgallia = EncounterHp(corgallia, process, display, rng);
                            break;
                        case 9://10% find special ability
                            corgallia = EncounterAbility(corgallia, process, display, rng);
                            break;
                    }
                    encounter = false;
                }

                //move when outside encounter
                //
                actions = CheckRooms(corgallia, dungeon);
                corgallia = process.GameMenuSelection(display.GameMenu(actions, dungeon, corgallia), corgallia);
                corgallia.CalcSteps();

                //roll for encounter
                //
                if (rng.Next(100) <= ENCOUNTERRATE * turnsWithoutEncounter)
                {
                    encounter = true;
                    turnsWithoutEncounter = 0;
                }
                else
                {
                    turnsWithoutEncounter++;
                }
            }

            display.GameOver(corgallia,dungeon,process);
        }

        public Player EncounterCombat(Player corgallia, Dungeon dungeon, Process process, Display display, Random rng)
        {
            string text = "", text2 = "", monsterStats = "";
            int num = 0, num2 = 0, num3 = 0, ranNum = 0;
            bool playerBlock = false, monsterBlock = false;
            SpAttack selectedSpAttack;
            EncounterAction action;
            List<EncounterAction> actions = new List<EncounterAction>() {EncounterAction.ATTACK, EncounterAction.DEFEND, EncounterAction.SPECIAL, EncounterAction.TALK };
            Monster monster = new Monster(dungeon, rng);

            switch (rng.Next(3))
            {
                case 0:
                    text = $"You encounter {monster.Name} the {monster.Type}.\nGet ready to rumble.";
                    break;
                case 1:
                    text = $"A wild {monster.Type} appears!\nTheir collar says \"{monster.Name}\"\nThey're probably an enemy.";
                    break;
                case 2:
                    text = $"You are greeted by a {monster.Type}.\nThey say their name is {monster.Name} and their favorite passtime is murder.\nYou would rather not get murdered.";
                    break;
            }

            while (monster.Hp > 0)
            {
                if (corgallia.Hp <= 0)
                {

                    display.GameOver(corgallia, dungeon, process, text + "\n\n" + text2);
                }
                num = 0;
                num2 = 0;
                num3 = 0;
                ranNum = 0;
                playerBlock = false;
                monsterStats = $"\n{monster.Name}:\nHP: {monster.Hp} | SP: {monster.Sp}";
                action = display.EncounterMenu(actions, corgallia, text + "\n\n" + text2 + "\n" + monsterStats);
                text = "";
                text2 = "";
                //player action
                //
                if (corgallia.GetsTurn)
                {
                    switch (action)
                    {
                        case EncounterAction.ATTACK:
                            num = rng.Next(1 + corgallia.Level) + corgallia.Level;
                            if (corgallia.Rage)
                            {
                                num += num;
                                text += $"You are hella pissed.";
                                if (rng.Next(2) == 1)
                                {
                                    text += $"You calmed down.";
                                    corgallia.Rage = false;
                                }
                            }
                            monster.Hp -= num;
                            text += $"You hit for {num}.";
                            break;
                        case EncounterAction.DEFEND:
                            playerBlock = true;
                            text += $"You raise your guard.";
                            break;
                        case EncounterAction.SPECIAL:
                            selectedSpAttack = display.SpAttackMenu(corgallia.Abilities, corgallia, text + "\n\n" + text2 + "\n" + monsterStats);
                            switch (selectedSpAttack)
                            {
                                case SpAttack.FROST_BOLT:
                                    num = rng.Next(1 + corgallia.Level) + 1;
                                    monster.Hp -= num;
                                    text += $"You fire a spear of ice from your paws. {monster.Name} gets blasted for {num} damage and frozen in place.";
                                    monster.GetsTurn = false;
                                    break;
                                case SpAttack.SUPLEX:
                                    text += $"The crowd goes wild!\nYou firmly grip {monster.Name} and whisper in their ear.\n\"welcome to the slam\"\nYou perform the most spectacular suplex ever seen.";
                                    num = rng.Next(corgallia.Hp);
                                    corgallia.Hp -= num;
                                    text += $"\nYou take {num} damage.";
                                    num = rng.Next(1, monster.Hp);
                                    monster.Hp -= num;
                                    text += $"\n{monster.Name} takes {num} damage.";
                                    break;
                                case SpAttack.FIRE_BALL:
                                    num = rng.Next(3 + corgallia.Level) + 1;
                                    monster.Hp -= num;
                                    text += $"You canjure a ball of flames and pitch it full speed at {monster.Name}'s head.\nYou inflict {num} damage and set them ablaze.";
                                    monster.HasBurn = true;
                                    break;
                                case SpAttack.GUN:
                                    if (corgallia.Sp == 3 + corgallia.Level)
                                    {
                                        corgallia.Sp = 0;
                                        text += $"You whip out your revolver.\nYou slam a bullet into each chamber.\nYou pull back the hammer\nSix bullets...";
                                        for (int i = 0; i < 6; i++)
                                        {
                                            num = rng.Next(5000);
                                            monster.Hp -= num;
                                            text += $"\nBLAM, {num} damage.";
                                        }
                                        text += "\nMore than enough to kill anything that moves.";
                                    }
                                    else
                                    {
                                        num = rng.Next(1 + corgallia.Level) + corgallia.Level;
                                        monster.Hp -= num;
                                        text += $"You don't have enough SP to fire the gun.\nYou pistol whip {monster.Name} instead.\nYou deal {num} damage.";
                                    }
                                    
                                    break;
                                case SpAttack.DROP_KICK:
                                    text += $"You drop kick the {monster.Type} with all four legs.";
                                    num = rng.Next(corgallia.Level);
                                    corgallia.Hp -= num;
                                    text += $"\nYou take {num} damage.";
                                    num = rng.Next(1, monster.Level);
                                    monster.Hp -= num;
                                    text += $"\n{monster.Name} takes {num} damage.";
                                    break;
                                case SpAttack.LICK:
                                    num = rng.Next(1 + corgallia.Level);
                                    monster.Hp -= num;
                                    monster.Sp -= num;
                                    if (monster.Sp < 0)
                                    {
                                        monster.Sp = 0;
                                    }
                                    text += $"You lick the {monster.Type}.\nThey look extremely uncomfortable.\nThey lose {num} SP & HP.";
                                    break;
                                case SpAttack.SHIELD:
                                    num = rng.Next(1 + corgallia.Level) + corgallia.Level;
                                    monster.Hp -= num;
                                    text += $"You shield slam {monster.Name} for {num} damage.\nYou keep the shield up to protect.";
                                    playerBlock = true;
                                    break;
                                case SpAttack.RAGE:
                                    corgallia.Rage = true;
                                    text += $"You slap yourself on the face.\nYou get pissed.";
                                    break;
                                case SpAttack.NAP:
                                    num = rng.Next(corgallia.Level + 5);
                                    corgallia.Hp += num;
                                    if (corgallia.Hp > 6 + (corgallia.Level * 2))
                                    {
                                        corgallia.Hp = 6 + (corgallia.Level * 2);
                                    }
                                    text += $"You take a power nap.\nYou heal for {num}";
                                    break;
                                case SpAttack.TELEPORT:
                                    corgallia.PPos[0] = rng.Next(dungeon.Width);
                                    corgallia.PPos[1] = rng.Next(dungeon.Height);
                                    if (dungeon.Map[corgallia.PPos[0], corgallia.PPos[1]] == true)
                                    {
                                        monster.Level = 0;
                                        monster.Hp = 0;
                                        text = $"You cast teleport.\nYou escaped having to actually deal with your problems.\nIf only you could teleport away from your debt.";
                                    }
                                    else
	                                {
                                        corgallia.Hp = 0;
                                        text = $"You cast teleport.\nYou don't know how to control it.\nYou teleported inside a solid wall.\nYou die instantly.";
                                    }
                                    break;
                                case SpAttack.SWARM:
                                    text += $"You swarm {monster.Name},";
                                    for (int i = 0; i < corgallia.Level+1; i++)
                                    {
                                        num = rng.Next(1, 3);
                                        monster.Hp -= num;
                                        text += $"\n{num} damage";
                                    }
                                    text += $"\nWhat a wallop.";
                                    break;
                            }
                            break;
                        case EncounterAction.TALK:
                            if (rng.Next(100) < 10 + corgallia.Level)
                            {
                                text += $"Your attempts at persuasion succeed.\n{monster.Name} decides to stop fighting.";
                                monster.Hp = 0;
                                monster.Level = 0;
                            }
                            else
                            {
                                switch (rng.Next(4))
                                {
                                    case 0:
                                        text += $"You tell {monster.Name} you don't want to fight.\nThey ignore you.";
                                        break;
                                    case 1:
                                        text += $"You cry for mercy. The {monster.Type} ignores your plee.";
                                        break;
                                    case 2:
                                        text += $"You offer {monster.Name} a hug.\nThey decline.";
                                        break;
                                    case 3:
                                        text += $"You tell {monster.Name} you don't want to fight.\nThey pretent not to hear you.";
                                        break;
                                    default:
                                        break;
                                }
                            }
                            break;
                        default:
                            text = "Something broke.";
                            break;
                    }
                }
                else
                {
                    text += $"\nYou took a turn to warm up.";
                    corgallia.GetsTurn = true;
                }

                if (corgallia.HasBurn)
                {
                    if (playerBlock)
                    {
                        text += "\nYou blocked the fire.";
                        corgallia.HasBurn = false;
                    }
                    else
                    {
                        num2 = rng.Next(monster.Level) + 1;
                        corgallia.Hp -= num2;
                        text += $"\nYou are on fire.\nYou take {num2} damage.";
                    }
                }

                //monster action
                //
                if (monster.GetsTurn)
                {
                    ranNum = rng.Next(6);
                    switch (ranNum)
                    {
                        case 0:
                        case 1:
                        case 2:
                            num2 = rng.Next(1 + monster.Level) + 1;
                            if (monster.Rage)
                            {
                                num2 += num2;
                                text2 += $"{monster.Name} is wicked mad.";
                                if (rng.Next(2) == 1)
                                {
                                    text2 += $"{monster.Name} took a chill pill.";
                                    monster.Rage = false;
                                }
                            }
                            if (!playerBlock)
                            {
                                corgallia.Hp -= num2;
                                text2 += $"{monster.Name} hits for {num2}.";
                            }
                            else
                            {
                                num3 = rng.Next(1, num2);
                                corgallia.Hp -= num2 - num3;
                                text2 += $"{monster.Name} hits for {num2}.\nYou blocked {num3} damage.";
                            }
                            break;
                        case 3:
                        case 4:
                            if (monster.Sp > 0)
                            {
                                monster.Sp--;
                                switch (monster.Power)
                                {
                                    case SpAttack.FROST_BOLT:
                                        num2 = rng.Next(1 + monster.Level);
                                        corgallia.Hp -= num2;
                                        text2 += $"{monster.Name} casts frost bolt, it deals {num2} damage.\nYou are frozen.";
                                        corgallia.GetsTurn = false;
                                        break;
                                    case SpAttack.SUPLEX:
                                        text2 += $"Holy jesus!\n{monster.Name} does a hella sick german suplex!";
                                        num2 = rng.Next(monster.Hp);
                                        monster.Hp -= num2;
                                        text2 += $"\n{monster.Name} takes {num2} damage.";
                                        num2 = rng.Next(1, corgallia.Hp);
                                        corgallia.Hp -= num2;
                                        text2 += $"\nYou take {num2} damage.";
                                        break;
                                    case SpAttack.FIRE_BALL:
                                        num2 = rng.Next(3 + monster.Level);
                                        corgallia.Hp -= num2;
                                        text2 += $"{monster.Name} casts fire ball, it deals {num2} damge.\nYou are on fire.";
                                        corgallia.HasBurn = true;
                                        break;
                                    case SpAttack.GUN:
                                        monster.Sp = 0;
                                        num2 = rng.Next(5000);
                                        corgallia.Hp -= num2;
                                        text2 += $"{monster.Name} shoots you with a gun.\nYou take {num2} damage.\nYes, {num2}.\nGuns are no joke.";
                                        break;
                                    case SpAttack.DROP_KICK:
                                        text2 += $"{monster.Name} does a dope drop kick from the top rope!";
                                        num2 = rng.Next(monster.Level);
                                        monster.Hp -= num2;
                                        text2 += $"\n{monster.Name} takes {num2} damage.";
                                        num2 = rng.Next(corgallia.Level);
                                        corgallia.Hp -= num2;
                                        text2 += $"\nYou take {num2} damage.";
                                        break;
                                    case SpAttack.LICK:
                                        num2 = rng.Next(1 + monster.Level);
                                        corgallia.Sp -= num2;
                                        if (corgallia.Sp < 0)
                                        {
                                            corgallia.Sp = 0;
                                        }
                                        text2 += $"{monster.Name} licks you.\nIt's super gross, you don't like it at all.\nYou lose {num2} SP";
                                        break;
                                    case SpAttack.SHIELD:
                                        num2 = rng.Next(1 + monster.Level);
                                        if (!playerBlock)
                                        {
                                            corgallia.Hp -= num2;
                                            text2 += $"{monster.Name} shield slams you for {num2} damage.";
                                        }
                                        else
                                        {
                                            num3 = rng.Next(1, num2);
                                            corgallia.Hp -= num2 - num3;
                                            text2 += $"{monster.Name} shield slams you for {num2} damage.\nYou blocked {num3} damage.";
                                        }
                                        num2 = rng.Next(num + 1);
                                        monster.Hp += num2;
                                        text2 += $"\n{monster.Name} blocked {num2} damage with their shield as they slammed you.";
                                        break;
                                    case SpAttack.RAGE:
                                        monster.Rage = true;
                                        text2 += $"{monster.Name} enrages themself.";
                                        break;
                                    case SpAttack.NAP:
                                        num2 = rng.Next(monster.Level);
                                        monster.Hp += num2;
                                        text2 += $"{monster.Name} does a good sleepy time.\nThey heal for {num2}";
                                        break;
                                    case SpAttack.TELEPORT:
                                        monster.Level = 0;
                                        monster.Hp = 0;
                                        text2 = $"{monster.Name} teleports away.\nWell ok then, um, you win.\nGood job I guess.";
                                        break;
                                    case SpAttack.SWARM:
                                        text2 += $"{monster.Name} swarms you,";
                                        for (int i = 0; i < monster.Level; i++)
                                        {
                                            num2 = rng.Next(1, 3);
                                            corgallia.Hp -= num2;
                                            text2 += $"\n{num2} damage";
                                        }
                                        text2 += $"\nOwchy.";
                                        break;
                                }
                            }
                            else
                            {
                                num2 = rng.Next(monster.Level);
                                corgallia.Hp -= num2;
                                text2 += $"{monster.Name} tried to cast {monster.Power}.\nThey failed like an idiot.\nTheir embarrassment is so painful it hurts.\nYou take {num2} damage.";
                            }

                            break;
                        case 5:
                            num2 = rng.Next(num + 1);
                            monster.Hp += num2;
                            text2 += $"{monster.Name} blocked {num2} damage.";
                            break;
                    }
                }
                else
                {
                    text2 += $"{monster.Name} takes a turn to warm up.";
                    monster.GetsTurn = true;
                }

                if (monster.HasBurn)
                {
                    if (monsterBlock)
                    {
                        text2 += $"{monster.Name} blocked the fire.";
                        monster.HasBurn = false;
                    }
                    else
                    {
                        num2 = rng.Next(corgallia.Level) + 1;
                        monster.Hp -= num2;
                        text2 += $"\n{monster.Name} is on fire.\nThey take {num2} damage.";
                    }
                }
            }

            if (rng.Next(10) < 5)
            {
                if (!corgallia.Abilities.Contains(monster.Power))
                {
                    corgallia.Abilities.Add(monster.Power);
                    text2 += $"\n\nYou learned {monster.Power} from the {monster.Type}.";
                }
            }

            text2 += $"\n\nCombat has ended.\nYou gained {monster.Level} XP";

            corgallia.CalcXp(monster.Level);

            actions = new List<EncounterAction> {EncounterAction.OK};
            action = display.EncounterMenu(actions, corgallia, text + "\n\n" + text2);

            return corgallia;
        }

        public Player EncounterPassive(Player corgallia, Process process, Display display, Random rng)
        {
            string text = "temp";
            List<EncounterAction> actions = new List<EncounterAction>() { EncounterAction.OK};

            switch (rng.Next(7))
            {
                case 0:
                    if (corgallia.Hp < 6 + (corgallia.Level * 2))
                    {
                        corgallia.Hp++;
                    }
                    text = "You found a piece of candy.\nYou eat it instantly without hesitation.\nIt was banana candy.\nYou feel better.";
                    break;
                case 1:
                    text = "A brick loosens from the ceiling and narrowly misses your head on the way down.\nLucky you.";
                    break;
                case 2:
                    if (corgallia.Sp < 3 + corgallia.Level)
                    {
                        corgallia.Sp++;
                    }
                    text = "You find an old dog bed hidden in an alcove in the wall.\nYou take a little nap.\nYou feel refreshed.";
                    break;
                case 3:
                    text = "You witness a mouse doing a backflip.\nIt was pretty rad.";
                    break;
                case 4:
                    corgallia.CalcXp(1);
                    text = "Against all odds you find a fire hydrant.\nYou fight your natural urges and move on.\nYou feel stronger.";
                    break;
                case 5:
                    text = "You hear a gunshot in the distance.\nAfter thorough investigation you conclude it was probably just the wind.";
                    break;
                case 6:
                    corgallia.HasKey = true;
                    text = "Well i'll be damned.\nYou found a key.\n";
                    break;
            }

            display.EncounterMenu(actions, corgallia, text);
            return corgallia;
        }

        public Player EncounterHp(Player corgallia, Process process, Display display, Random rng)
        {
            string text = "temp";
            List<EncounterAction> actions = new List<EncounterAction>() {EncounterAction.EAT, EncounterAction.DECLINE };
            EncounterAction action = EncounterAction.OK;

            switch (rng.Next(4))
            {
                case 0:
                case 1:
                case 2:
                    text = "You stumble upon a vial of mysterious liquid.\nIt's cold to the touch.\nWill you slurp it down?";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.EAT)
                    {
                        corgallia.Hp = corgallia.Hp + rng.Next(4, 10 + corgallia.Level);
                        if (corgallia.Hp > 6 + (corgallia.Level * 2))
                        {
                            corgallia.Hp = 6 + (corgallia.Level * 2);
                        }
                        text = "It was a nice cold refreshing Bepsi.\nYou feel much better.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "Probably for the best.";
                        actions = new List<EncounterAction> { EncounterAction.OK};
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
                case 3:
                    text = "You stumble upon a vial of mysterious liquid.\nIt's warm to the touch.\nWill you slurp it down?";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.EAT)
                    {
                        corgallia.Hp = corgallia.Hp - rng.Next(1, 10 + corgallia.Level);
                        text = "Your insides are on fire.\nWhy would you drink a random vial off the floor of a crpyt.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "Probably for the best.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
            }

            return corgallia;
        }

        public Player EncounterSp(Player corgallia, Process process, Display display, Random rng)
        {
            string text = "temp";
            List<EncounterAction> actions = new List<EncounterAction>() { EncounterAction.ACCEPT, EncounterAction.DECLINE };
            EncounterAction action = EncounterAction.OK;

            switch (rng.Next(4))
            {
                case 0:
                case 1:
                case 2:
                    text = "A fountain of clear water springs from a crack in the wall.\nDo you wish to play in it?";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.ACCEPT)
                    {
                        corgallia.Sp = corgallia.Sp + rng.Next(1, 4 + corgallia.Level);
                        if (corgallia.Sp > 3 + corgallia.Level)
                        {
                            corgallia.Sp = 3 + corgallia.Level;
                        }
                        text = "You spend hours rolling in the water before falling asleep.\nWhen you awake the water is gone.\nYou feel refreshed.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "No time to play.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
                case 3:
                    text = "A fountain of sparkling water springs from a crack in the wall.\nDo you wish to play in it?";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.ACCEPT)
                    {
                        corgallia.Sp = corgallia.Sp - rng.Next(1, 4 + corgallia.Level);
                        text = "The water was electric.\nThe exact opposite of refreshing.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "No time to play.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
            }

            return corgallia;
        }

        public Player EncounterAbility(Player corgallia, Process process, Display display, Random rng)
        {
            string text = "temp";
            List<EncounterAction> actions = new List<EncounterAction>() { EncounterAction.TALK, EncounterAction.DECLINE};
            List<SpAttack> abilities = new List<SpAttack>() {SpAttack.FIRE_BALL, SpAttack.FROST_BOLT, SpAttack.SUPLEX,SpAttack.DROP_KICK,SpAttack.TELEPORT};
            EncounterAction action = EncounterAction.OK;

            switch (rng.Next(4))
            {
                case 0:
                case 1:
                case 2:
                    text = "A figure emerges from the shadows.\nThey are wearing black robes.\nThey ask your name.";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.TALK)
                    {
                        corgallia.Abilities.Add(abilities[rng.Next(abilities.Count)]);
                        text = "You talk for hours.\nTurns out they also got trapped down here.\nThey share their knoledge with you before leaving.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "You remain silent.\nThe man akwardly waits in silence for a moment before leaving.\nSocial anxiety ruins another potential friendship.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
                case 3:
                    text = "A figure emerges from the shadows.\nThey are wearing white robes.\nThey ask your name.";
                    action = display.EncounterMenu(actions, corgallia, text);
                    if (action == EncounterAction.TALK)
                    {
                        if (corgallia.Abilities.Count > 1)
                        {
                            corgallia.Abilities.RemoveAt(0);
                        }
                        text = "You awake with amnesia.\nNo idea what happened.\n";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    else
                    {
                        text = "You remain silent.\nThe man akwardly waits in silence for a moment before leaving.\nSocial anxiety ruins another potential friendship.";
                        actions = new List<EncounterAction> { EncounterAction.OK };
                        display.EncounterMenu(actions, corgallia, text);
                    }
                    break;
            }

            return corgallia;
        }

        public List<GameAction> CheckRooms(Player corgallia, Dungeon dungeon)
        {
            List<GameAction> actions = new List<GameAction>();
            if (dungeon.Map[corgallia.PPos[0], corgallia.PPos[1] - 1] == true)
            {
                actions.Add(GameAction.MOVE_NORTH);
            }
            if (dungeon.Map[corgallia.PPos[0], corgallia.PPos[1] + 1] == true)
            {
                actions.Add(GameAction.MOVE_SOUTH);
            }
            if (dungeon.Map[corgallia.PPos[0] - 1, corgallia.PPos[1]] == true)
            {
                actions.Add(GameAction.MOVE_WEST);
            }
            if (dungeon.Map[corgallia.PPos[0] + 1, corgallia.PPos[1]] == true)
            {
                actions.Add(GameAction.MOVE_EAST);
            }
            return actions;
        }

        public void PlayIntro(Process process)
        {
            Console.CursorVisible = false;
            Console.Clear();
            process.TypeText("It was a dark and stormy night in the pet cemetery.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("Corgallia the petty grave robber was hard at work.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("B O O M", 200);
            process.TypeText("Lightning lashed the earth with malicious intent.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("The ground twisted and groanded under her feet.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("The living dead rose from the freshly re-dug graves.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("Struck with fear she sprinted on all fours towards the mausoleum.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("She burst through the gate and hastily barred it behind her.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("A rushed examination revealed nothing but the large pit in the center of the room.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("The rightfully pissed living dead thrashed the gate.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("As the barricade began to buckle Corgallia had no choice.", 50);
            System.Threading.Thread.Sleep(1000);
            process.TypeText("She grabbed a torch, closed her eyes, and dropped to the depths below.", 50);
            System.Threading.Thread.Sleep(2000);
        }
    }
}
