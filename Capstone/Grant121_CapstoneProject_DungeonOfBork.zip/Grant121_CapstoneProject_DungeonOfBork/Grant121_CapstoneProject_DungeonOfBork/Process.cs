﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_CapstoneProject_DungeonOfBork
{
    public class Process
    {
        #region methods

        /// <summary>
        /// print out string one character at a time
        /// </summary>
        /// <param name="text">string to print</param>
        /// <param name="speed">speed in miliseconds to print at</param>
        public void TypeText(string text, int speed)
        {
            Random rng = new Random();

            for (int i = 0; i < text.Length; i++)
            {
                Console.Write(text[i]);
                switch (text[i].ToString())
                {
                    case " ":
                        System.Threading.Thread.Sleep(speed);
                        break;
                    default:
                        Console.Beep(rng.Next(200,300), speed);
                        break;
                }
            }
            Console.WriteLine();
        }

        public void MainMenuSelection(MainMenuOption selected, Display display)
        {
            //process selected option
            //
            Game game = new Game();
            switch (selected)
            {
                case MainMenuOption.START:
                    game.PlayIntro(new Process());
                    game.MainGameApp();
                    break;
                case MainMenuOption.OPTIONS:
                    MainMenuSelection(display.MainMenu(new MainMenuOption[4] { MainMenuOption.FGCOLOR, MainMenuOption.BGCOLOR, MainMenuOption.NO_INTRO, MainMenuOption.BACK }), display);
                    break;
                case MainMenuOption.EXIT:
                    Environment.Exit(0);
                    break;
                case MainMenuOption.BGCOLOR:
                    display.ColorMenu(true, display);
                    break;
                case MainMenuOption.FGCOLOR:
                    display.ColorMenu(false, display);
                    break;
                case MainMenuOption.BACK:
                    MainMenuSelection(display.MainMenu(new MainMenuOption[3] { MainMenuOption.START, MainMenuOption.OPTIONS, MainMenuOption.EXIT }), display);
                    break;
                case MainMenuOption.NO_INTRO:
                    game.MainGameApp();
                    break;
            }
        }

        public Player GameMenuSelection(GameAction selected, Player corgallia)
        {
            switch (selected)
            {
                case GameAction.MOVE_NORTH:
                    corgallia.PPos[1]--;
                    break;
                case GameAction.MOVE_EAST:
                    corgallia.PPos[0]++;
                    break;
                case GameAction.MOVE_SOUTH:
                    corgallia.PPos[1]++;
                    break;
                case GameAction.MOVE_WEST:
                    corgallia.PPos[0]--;
                    break;
                default:
                    Console.WriteLine("broke");
                    break;
            }

            return corgallia;
        }

        #endregion
    }
}
