﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grant121_SimpleMonsterClasses
{
    public enum SeaMonsterType
    {
        Fish
        , Cephalopod
        , Crustation
        , Jelly
    }

    public enum FurryMonsterType
    {
        Dog
        , Cat
        , Rat
        , Horse
    }
}
