﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA_CommandList
{
    static class DefaultFinchConfig
    {
        public const int NUMBER_OF_COMMNANDS = 6;
        public const int DELAY_DURATION = 1000;
        public const int MOTOR_SPEED = 100;
        public const int LED_BRIGHTNESS = 200;
    }
}
